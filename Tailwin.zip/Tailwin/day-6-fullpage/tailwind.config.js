/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
     colors:{
      primaryColor:"#008000",
      secondaryColor:"orange"
     },
     fontFamily:{
      'primaryFont' :["Inter", 'sans-serif'],
      'secondaryFont':["Poppins", "sans-serif"]      
     },
     fontSize:{
      smaller:'12px'
     }

    },
  },
  plugins: [],
}

