const navDilog = document.getElementById('nav-dialog')
function mobileNavHandler(){
    navDilog.classList.toggle('hidden')
   
}


const initialTranslateLTR = -48*4;
const initialTranslateRTL = -36*4;


function setupIntersectionObserve(element, isLtr, speed){

    const intersectionCallback = (entries)=>{
        const isIntersect = entries[0].isIntersecting // this is return ture or valse
        console.log(element, isIntersect)

        if(isIntersect){
            document.addEventListener('scroll', scrllHandlerFunc)
        }
        else{
            document.removeEventListener('scroll', scrllHandlerFunc)
        }

        function scrllHandlerFunc(){
            const translateX = (window.innerHeight - element.getBoundingClientRect().top)*speed;
           // console.log(translateX)

           let totalTranslate =0;
           if(isLtr){
            totalTranslate = translateX + initialTranslateLTR
           }
           else{
            totalTranslate = -translateX + initialTranslateRTL 
           }
            element.style.transform = `translateX(${totalTranslate}px)`
        }
       
    }
    const interSectionObserver = new IntersectionObserver(intersectionCallback)


    /*
    
    const interSectionObserver = new IntersectionObserver((entries)=>{
        const isIntersecting = entries[0].isIntersecting
        console.log(element, isIntersecting)
    })
*/
    interSectionObserver.observe(element)
}

const line1 = document.getElementById('line1');
const line2 = document.getElementById('line2');
const line3 = document.getElementById('line3');
const line4 = document.getElementById('feature-line');



setupIntersectionObserve(line1, true, 0.15)
setupIntersectionObserve(line2, false, 0.15)
setupIntersectionObserve(line3, true, 0.15)
setupIntersectionObserve(line4, true, 0.8)