gsap.registerPlugin(ScrollTrigger);

// Locomotive code with scroll Triager
    const locoScroll = new LocomotiveScroll({
    el: document.querySelector("#main"),
    smooth: true
    });
    locoScroll.on("scroll", ScrollTrigger.update);
    ScrollTrigger.scrollerProxy("#main", {
    scrollTop(value) {
        return arguments.length ? locoScroll.scrollTo(value, 0, 0) : locoScroll.scroll.instance.scroll.y;
    }, 
    getBoundingClientRect() {
        return {top: 0, left: 0, width: window.innerWidth, height: window.innerHeight};
    },
    pinType: document.querySelector("#main").style.transform ? "transform" : "fixed"
    });
    ScrollTrigger.addEventListener("refresh", () => locoScroll.update());
    ScrollTrigger.refresh();
// End Locomotive Scroll




//Without gsap (using cor javaScript)
    /*
        var page1 = document.querySelector('#page1');
        var page2 = document.querySelector('#page2');
        var mouse1 = document.querySelector('#cursor');
            page1.addEventListener('mousemove',function(raj){  
                    mouse1.style.left= raj.x+"px";
                    mouse1.style.top= raj.y+"px";
            })
    */
    


function mouseCursor(){

    var page1 = document.querySelector('#page1');
    page1.addEventListener('mousemove',function(raj){  
            gsap.to('#cursor',{
                x:raj.x,
                y:raj.y,
                opacity:raj.x,
              
            })  
    })
    page1.addEventListener('wheel',function(raj){  
        gsap.to('#cursor',{
            duration:0,
            x:raj.x,
            y:raj.y,
            opacity:raj.x,
          
        })  
})
    page1.addEventListener('mouseenter',function(){
        gsap.to('#cursor', {
            scale:1,
            opacity:1,
        
        })
    })
    page1.addEventListener('mouseleave',function(){
            gsap.to('#cursor', {
                delay:0,
                duration:0.5,
                scale:0,
                opacity:0,
            })
    })
}



mouseCursor()




function page2(){
   // gsap.registerPlugin(ScrollTrigger);   
    gsap.from("#page2 p", {
        y: 100,
        opacity:0.5,
        stagger:0.2,
        duration:1,
        scrollTrigger: {
            trigger: '#page2',
            scroller:"#main",
            start:"top 47%",
            end:"top 46%",
            scrub:2,
        }
    });

}

page2()

  