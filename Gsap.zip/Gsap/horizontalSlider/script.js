gsap.registerPlugin(ScrollTrigger);

let masks = gsap.utils.toArray(".img-mask");

gsap.to(masks[1], {
  height: "0%",
  ease: "none",
  scrollTrigger: {
    trigger: ".revealer",
    start: "top top",
    pin: true,
    end: "+=100%",
    scrub: 0.5
  }
});