console.clear(); // Start with a clean console on refesh
gsap.registerPlugin(ScrollToPlugin, ScrollTrigger);

let panelsContainer = document.querySelector(".main-slide"),
  tween;
let panels = gsap.utils.toArray(".main-slide .slide-item .item");
const width = window.innerWidth * (panels.length - 1); // get width of all elments
const links = gsap.utils.toArray(".navTitle");
const modifiedLength = links.length - 1;
console.log(links);
let activeLink = 0;
const snapPoints = links.map((_, i) => i / modifiedLength);
const mySnap = gsap.utils.snap(snapPoints);
links[activeLink].classList.toggle("active");

function setupScrollTweens() {
  tween = gsap.to(panels, {
    yPercent: -100 * (panels.length - 1),
    ease: "none",
    scrollTrigger: {
      trigger: ".main-slide",
      pin: true,
      scrub: 0.1,
      end: `+=3500`, // same width as all elments
      onUpdate: (self) => {
        const newIndex = mySnap(self.progress) * modifiedLength;
        if (newIndex !== activeLink) {
          links[activeLink].classList.toggle("active");
          links[newIndex].classList.toggle("active");
          activeLink = newIndex;
        }
      }
    }
  });
}

// Setup the scroll tweens when the page loads
setupScrollTweens();

const range = gsap.utils.mapRange(0, width, 0, tween.scrollTrigger.end);

// navTitle to anchor to the target slide
document.querySelectorAll(".navTitle").forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();

    let targetElem = document.querySelector(e.target.getAttribute("href"));
    console.warn(targetElem.offsetLeft);
    gsap.to(window, {
      scrollTo: {
        y: () => range(targetElem.offsetLeft), // animate the the left side
        autoKill: false
      },
      duration: 0.5
    });
  });
});