
'use client'
import React, { useRef, useState } from 'react';
// component
import { Swiper, SwiperSlide } from 'swiper/react';

//module
import { Navigation, Autoplay, Pagination} from 'swiper/modules';

import 'swiper/css';
import 'swiper/css/pagination';

import './horizontalSlider.css';


export default function slider() {
   
  return (
    <Swiper

    modules={[Navigation, Autoplay, Pagination]}


    direction={'vertical'}
    pagination={{
      clickable: true,
    }}

    className="mySwiper"
    
    >
        <SwiperSlide><img src='https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Taj_Mahal_%28Edited%29.jpeg/1200px-Taj_Mahal_%28Edited%29.jpeg' style={{height:"20%"}} /></SwiperSlide>
        <SwiperSlide><img src='https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Taj_Mahal_%28Edited%29.jpeg/1200px-Taj_Mahal_%28Edited%29.jpeg' style={{height:"20%"}} /></SwiperSlide>
        <SwiperSlide><img src='https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Taj_Mahal_%28Edited%29.jpeg/1200px-Taj_Mahal_%28Edited%29.jpeg' style={{height:"20%"}} /></SwiperSlide>
        <SwiperSlide><img src='https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Taj_Mahal_%28Edited%29.jpeg/1200px-Taj_Mahal_%28Edited%29.jpeg' style={{height:"20%"}} /></SwiperSlide>

  </Swiper>
  )
}


