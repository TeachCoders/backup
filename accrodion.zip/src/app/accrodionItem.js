
'use client'
import React, { useState } from 'react';

const Accordion = () => {
let [equalIndex, setEqualIndex] = useState(null)



const items = [
    {
      title: 'Section 1',
      desc: 'Content of section 1'
    },
    {
      title: 'Section 2',
      desc: 'Content of section 2'
    },
    {
      title: 'Section 3',
      desc: 'Content of section 3'
    }
  ];


  return (
    <div>
       {
         items.map((x, index)=>{
            return(
                <>
                <h1 onClick={()=>{setEqualIndex(index)}}>                    
                    {x.title}  <span>{equalIndex===index ? '-' : '+'}</span>                  
                </h1>
                    
                {equalIndex===index ?  <p>{x.desc}</p> : null}
                
                </>
            ) 
         })
       }
   
    </div>
  );
};

export default Accordion;
