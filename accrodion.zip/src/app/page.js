import Image from "next/image";
import styles from "./page.module.css";
// import Accordion from "./accrodionItem";

import SingaleAccrodion from "./singaleAccrodion";
import Slider from "./slider";



export default function Home() {
  return (
    <main>
      <slider />
      <div>
      <h1>Accordion Example</h1>
      {/* <Accordion  />  */}
      <SingaleAccrodion />

      <Slider />
    </div>
    </main>
  );
}
