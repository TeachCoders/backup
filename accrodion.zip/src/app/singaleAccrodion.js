'use client'

import { useState } from "react"
export default function singaleAccrodion() {

    let [toggle, setToggle] = useState(null)

    return (
        <>
            <h1 onClick={() => { setToggle(!toggle ? true : null) }}>
                heading {toggle ? "-" : "+"}
            </h1>

            {toggle ? <p>Description</p> : null}

        </>
    )
}
